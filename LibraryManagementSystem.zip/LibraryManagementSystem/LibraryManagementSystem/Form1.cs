﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.Items.Add("user");
            comboBox1.Items.Add("admin");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (textBox1.Text != "" && textBox2.Text != "")
            {

                string query = "select type from login where id =" + textBox1.Text + " AND password='" + textBox2.Text + "'";
                string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                SqlConnection myConnection = new SqlConnection(myConnectionString);
                myConnection.Open();
                SqlCommand myCommand = new SqlCommand(query, myConnection);
                string utype = (string)myCommand.ExecuteScalar();
                myConnection.Close();

                if (utype == "admin") {
                    MessageBox.Show("Logging In");
                    int x = Int32.Parse(textBox1.Text);
                    AdminHome ah = new AdminHome(x);
                    ah.Visible = true;
                    this.Visible = false;
                }
                else if (utype == "user")
                {



                    query = "select * from login where id =" + textBox1.Text + "AND password='" + textBox2.Text + "'";
                    myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                    myConnection = new SqlConnection(myConnectionString);
                    myConnection.Open();
                    myCommand = new SqlCommand(query, myConnection);
                    SqlDataReader dr = myCommand.ExecuteReader();


                    if (dr.HasRows)
                    {
                        int i = Int32.Parse(textBox1.Text);
                        string type;
                        myConnection.Close();
                        query = "select type from login where id =" + textBox1.Text + "";
                        myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                        myConnection = new SqlConnection(myConnectionString);
                        myConnection.Open();
                        myCommand = new SqlCommand(query, myConnection);
                        type = (string)myCommand.ExecuteScalar();

                        MessageBox.Show("Logging In");
                        Home h = new Home(i, type);
                        h.Visible = true;
                        this.Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("ID or Password is incorrect");
                    }
                    myConnection.Close();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox3.Text != "" && textBox4.Text != "" && comboBox1.Text != ""&&textBox5.Text!="")
            {
                if (comboBox1.Text == "admin")
                {
                    

                    string query = "select pin from adminPin";
                    string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                    SqlConnection myConnection = new SqlConnection(myConnectionString);
                    myConnection.Open();
                    SqlCommand myCommand = new SqlCommand(query, myConnection);
                    int v = (int)myCommand.ExecuteScalar();
                    myConnection.Close();
                    int x = Int32.Parse(textBox6.Text);
                    if (x == v)
                    {

                        query = "insert into login values ('" + textBox3.Text + "','" + textBox4.Text + "','" + comboBox1.Text + "'," + 500 + ",'" + textBox5.Text + "')";
                        myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                        myConnection = new SqlConnection(myConnectionString);
                        myConnection.Open();
                        myCommand = new SqlCommand(query, myConnection);
                        myCommand.ExecuteNonQuery();
                        myConnection.Close();

                        query = "select id from login where name='"+textBox3.Text+"' AND password='"+textBox4.Text+"' AND type='"+comboBox1.Text+"' AND balance=500 AND address='"+textBox5.Text+"'";
                        myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                        myConnection = new SqlConnection(myConnectionString);
                        myConnection.Open();
                        myCommand = new SqlCommand(query, myConnection);
                        int v1 = (int)myCommand.ExecuteScalar();
                        myConnection.Close();

                        MessageBox.Show("Account Created\n\nYOUR ID IS: " + v1 + "\n\nYOUR PASSWORD IS: " + textBox4.Text);
                        

                        textBox3.Text = "";
                        textBox4.Text = "";
                        comboBox1.Text = "";
                        textBox5.Text = "";
                        textBox6.Text = "";
                        textBox6.Visible = false;
                        label8.Visible = false;
                    }
                    else {
                        MessageBox.Show("Pin is incorrect!");
                    }
                    

                }
                else if(comboBox1.Text=="user")
                {
                    string query = "insert into login values ('" + textBox3.Text + "','" + textBox4.Text + "','" + comboBox1.Text + "'," + 500 + ",'"+textBox5.Text+"')";
                    string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                    SqlConnection myConnection = new SqlConnection(myConnectionString);
                    myConnection.Open();
                    SqlCommand myCommand = new SqlCommand(query, myConnection);
                    myCommand.ExecuteNonQuery();
                    myConnection.Close();

                    query = "select id from login where name='" + textBox3.Text + "' AND password='" + textBox4.Text + "' AND type='" + comboBox1.Text + "' AND balance=500 AND address='" + textBox5.Text + "'";
                    myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                    myConnection = new SqlConnection(myConnectionString);
                    myConnection.Open();
                    myCommand = new SqlCommand(query, myConnection);
                    int v1 = (int)myCommand.ExecuteScalar();
                    myConnection.Close();

                    MessageBox.Show("Account Created\n\nYOUR ID IS: " + v1+"\n\nYOUR PASSWORD IS: "+textBox4.Text);

                    textBox3.Text = "";
                    textBox4.Text = "";
                    comboBox1.Text = "";
                    textBox5.Text = "";
                    textBox6.Text = "";
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "admin") {
                textBox6.Visible = true;
                label8.Visible = true;
            }
            else if (comboBox1.Text == "user") {
                textBox6.Visible = false;
                label8.Visible = false;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
