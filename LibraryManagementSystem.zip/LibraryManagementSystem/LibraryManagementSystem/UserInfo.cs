﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class UserInfo : Form
    {
        private int userId;
        private string userType;
        public UserInfo(int i,string t)
        {
            InitializeComponent();
            userId = i;
            userType=t;


            string query = "select * from login where id="+userId+"";
            string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            SqlConnection myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            SqlCommand myCommand = new SqlCommand(query, myConnection);
            SqlDataReader dr = myCommand.ExecuteReader();
            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridView1.DataSource = dt;
            }
            myConnection.Close();


            query = "select * from userhistory where id=" + userId + "";
            myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            myCommand = new SqlCommand(query, myConnection);
            dr = myCommand.ExecuteReader();
            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridView2.DataSource = dt;
            }
            myConnection.Close();
        }

        private void UserInfo_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Home h = new Home(userId, userType);
            h.Visible = true;
            this.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Visible = true;
            this.Visible = false;
        }
    }
}
