﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class Borrow : Form
    {
        private int userId,bookQuantity=0,bookAvailable=0;
        private double userBalance,bookValue;
        private string userType,bookName,author,userName,actBr="borrowed",actBy="bought";
        public Borrow(int i,string s,string s1,string s2)
        {
            InitializeComponent();
            userId = i;
            userType = s;
            bookName = s1;
            author = s2;

            string query = "select balance from login where id =" + userId + "";
            string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            SqlConnection myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            SqlCommand myCommand = new SqlCommand(query, myConnection);
            userBalance = (double)myCommand.ExecuteScalar();
            myConnection.Close();

            query = "select price from book where bookname ='" + bookName + "' AND authorname='" + author + "'";
            myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            myCommand = new SqlCommand(query, myConnection);
            bookValue = (double)myCommand.ExecuteScalar();
            myConnection.Close();

            query = "select quantity from book where bookname ='" + bookName + "' AND authorname='" + author + "'";
            myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            myCommand = new SqlCommand(query, myConnection);
            bookQuantity = (int)myCommand.ExecuteScalar();
            myConnection.Close();

            query = "select available from book where bookname ='" + bookName + "' AND authorname='" + author + "'";
            myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            myCommand = new SqlCommand(query, myConnection);
            bookAvailable = (int)myCommand.ExecuteScalar();
            myConnection.Close();

            query = "select name from login where id ="+userId+"";
            myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            myCommand = new SqlCommand(query, myConnection);
            userName = (string)myCommand.ExecuteScalar();
            myConnection.Close();


            
        }

        private void Borrow_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked) {

                if (bookQuantity != 0 && bookAvailable != 0)
                {
                    if (userBalance - bookValue < 0)
                    {
                        MessageBox.Show("You do not have enough Balance !");
                    }
                    else
                    {
                        userBalance -= bookValue;
                        bookQuantity -= 1;
                        if (bookQuantity == 0) {
                            bookAvailable = 0;
                        }
                        string query = "update book set quantity =" + bookQuantity + "where bookname ='" + bookName + "' AND authorname='" + author + "'";
                        string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                        SqlConnection myConnection = new SqlConnection(myConnectionString);
                        myConnection.Open();
                        SqlCommand myCommand = new SqlCommand(query, myConnection);
                        myCommand.ExecuteNonQuery();
                        myConnection.Close();

                        query = "update book set available =" + bookAvailable + "where bookname ='" + bookName + "' AND authorname='" + author + "'";
                        myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                        myConnection = new SqlConnection(myConnectionString);
                        myConnection.Open();
                        myCommand = new SqlCommand(query, myConnection);
                        myCommand.ExecuteNonQuery();
                        myConnection.Close();

                        query = "update login set balance =" + userBalance + "where id =" + userId + "";
                        myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                        myConnection = new SqlConnection(myConnectionString);
                        myConnection.Open();
                        myCommand = new SqlCommand(query, myConnection);
                        myCommand.ExecuteNonQuery();
                        myConnection.Close();

                        query = "insert into userhistory values (" + userId + ",'" + userName + "','" + bookName +"','"+author+ "','"+actBy+"',"+0+","+1+")";
                        myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                        myConnection = new SqlConnection(myConnectionString);
                        myConnection.Open();
                        myCommand = new SqlCommand(query, myConnection);
                        myCommand.ExecuteNonQuery();
                        myConnection.Close();

                        NextBuy n = new NextBuy(userId, userType, bookName, author);
                        n.Visible = true;
                        this.Visible = false;
                    }
                }
                else {
                    MessageBox.Show("Sorry!! Book is not Available");
                }
            }
            else if (radioButton2.Checked) {

                if (bookQuantity != 0 && bookAvailable != 0)
                {

                        bookQuantity -= 1;
                        if (bookQuantity == 0)
                        {
                            bookAvailable = 0;
                        }


                        string query = "update book set quantity =" + bookQuantity + "where bookname ='" + bookName + "' AND authorname='" + author + "'";
                        string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                        SqlConnection myConnection = new SqlConnection(myConnectionString);
                        myConnection.Open();
                        SqlCommand myCommand = new SqlCommand(query, myConnection);
                        myCommand.ExecuteNonQuery();
                        myConnection.Close();

                        query = "update book set available =" + bookAvailable + "where bookname ='" + bookName + "' AND authorname='" + author + "'";
                        myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                        myConnection = new SqlConnection(myConnectionString);
                        myConnection.Open();
                        myCommand = new SqlCommand(query, myConnection);
                        myCommand.ExecuteNonQuery();
                        myConnection.Close();

                        query = "insert into userhistory values (" + userId + ",'" + userName + "','" + bookName + "','" + author + "','" + actBr + "'," + 0 + ","+1+")";
                        myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                        myConnection = new SqlConnection(myConnectionString);
                        myConnection.Open();
                        myCommand = new SqlCommand(query, myConnection);
                        myCommand.ExecuteNonQuery();
                        myConnection.Close();


                        NextBorrow nb = new NextBorrow(userId, userType, bookName, author);
                        nb.Visible = true;
                        this.Visible = false;
                    
                }
                else {
                    MessageBox.Show("Sorry!! Book is not Available");
                }
                
            }

        }



        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Home h = new Home(userId, userType);
            h.Visible = true;
            this.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Visible = true;
            this.Visible = false;
        }
    }
}
