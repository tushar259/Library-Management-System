﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class ReturnBook : Form
    {
        private int userId;
        private string userType,s,s2,rten="returned";
        public ReturnBook(int i,string t)
        {
            InitializeComponent();
            userId = i;
            userType = t;

            string query = "select * from userhistory where id=" + userId + "";
            string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            SqlConnection myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            SqlCommand myCommand = new SqlCommand(query, myConnection);
            SqlDataReader dr = myCommand.ExecuteReader();
            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridView1.DataSource = dt;
            }
            myConnection.Close();

            query = "select bookname from userhistory where id="+userId+"";
            myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            myCommand = new SqlCommand(query, myConnection);
            dr = myCommand.ExecuteReader();
            while (dr.Read())
            {
                s = dr.GetString(0);
                comboBox1.Items.Add(s);
            }
            myConnection.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string query = "select authorname from userhistory where bookname='" + comboBox1.Text + "'";
            string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            SqlConnection myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            SqlCommand myCommand = new SqlCommand(query, myConnection);
            SqlDataReader dr = myCommand.ExecuteReader();
            while (dr.Read())
            {
                s2 = dr.GetString(0);
                comboBox2.Items.Add(s2);
            }
            myConnection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != "" && comboBox2.Text != "")
            {
                string query = "update userhistory set activity = '" + rten + "' where id=" + userId + " AND bookname='" + comboBox1.Text + "' AND authorname='" + comboBox2.Text + "'";
                string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                SqlConnection myConnection = new SqlConnection(myConnectionString);
                myConnection.Open();
                SqlCommand myCommand = new SqlCommand(query, myConnection);
                myCommand.ExecuteNonQuery();
                myConnection.Close();

                query = "update userhistory set confirm = " + 0 + " where id=" + userId + " AND bookname='" + comboBox1.Text + "' AND authorname='" + comboBox2.Text + "'";
                myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                myConnection = new SqlConnection(myConnectionString);
                myConnection.Open();
                myCommand = new SqlCommand(query, myConnection);
                myCommand.ExecuteNonQuery();
                myConnection.Close();

                MessageBox.Show("Your book will be returned");

                comboBox1.Text = "";
                comboBox2.Text = "";
            }
            else {
                MessageBox.Show("Please enter values");
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Home h = new Home(userId, userType);
            h.Visible = true;
            this.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Visible = true;
            this.Visible = false;
        }

        private void ReturnBook_Load(object sender, EventArgs e)
        {

        }
    }
}
