﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class AdminBookInfo : Form
    {
        private int userId,tempv;
        public AdminBookInfo(int i)
        {
            InitializeComponent();
            userId = i;


            string query = "select * from book";
            string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            SqlConnection myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            SqlCommand myCommand = new SqlCommand(query, myConnection);
            SqlDataReader dr = myCommand.ExecuteReader();
            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridView1.DataSource = dt;
            }
            myConnection.Close();



        }

        private void AdminBookInfo_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            AdminHome ah = new AdminHome(userId);
            ah.Visible = true;
            this.Visible = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Visible = true;
            this.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && textBox6.Text != "")
            {
                string query = "insert into book values ('" + textBox1.Text + "'," + textBox2.Text + ",'" + textBox3.Text + "'," + textBox4.Text + "," + textBox5.Text + "," + textBox6.Text + ")";
                string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                SqlConnection myConnection = new SqlConnection(myConnectionString);
                myConnection.Open();
                SqlCommand myCommand = new SqlCommand(query, myConnection);
                myCommand.ExecuteNonQuery();
                myConnection.Close();

                MessageBox.Show("Book Added");
                textBox1.Text = ""; textBox2.Text = ""; textBox3.Text = ""; textBox4.Text = ""; textBox5.Text = ""; textBox6.Text = "";

            }
            else {
                MessageBox.Show("Please Enter Values");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string query = "select * from book";
            string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            SqlConnection myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            SqlCommand myCommand = new SqlCommand(query, myConnection);
            SqlDataReader dr = myCommand.ExecuteReader();
            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridView1.DataSource = dt;
            }
            myConnection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox7.Text != "" && textBox8.Text != "" && textBox9.Text != "")
            {
                int x = Int32.Parse(textBox9.Text);
                string query = "select quantity from book where bookname='" + textBox7.Text + "' AND authorname='" + textBox8.Text + "'";
                string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                SqlConnection myConnection = new SqlConnection(myConnectionString);
                myConnection.Open();
                SqlCommand myCommand = new SqlCommand(query, myConnection);
                int v1 = (int)myCommand.ExecuteScalar();
                myConnection.Close();

                v1 += x;

                query = "update book set quantity =" + v1 + "where bookname ='" + textBox7.Text + "' AND authorname='" + textBox8.Text + "'";
                myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                myConnection = new SqlConnection(myConnectionString);
                myConnection.Open();
                myCommand = new SqlCommand(query, myConnection);
                myCommand.ExecuteNonQuery();
                myConnection.Close();

                MessageBox.Show("Book Added");

                textBox7.Text = ""; textBox8.Text = ""; textBox9.Text = "";

            }
            else
            {
                MessageBox.Show("Please Enter Values");
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox12.Text != "" && textBox11.Text != "" && textBox10.Text != "")
            {
                int x = Int32.Parse(textBox10.Text);
                string query = "select quantity from book where bookname='" + textBox12.Text + "' AND authorname='" + textBox11.Text + "'";
                string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                SqlConnection myConnection = new SqlConnection(myConnectionString);
                myConnection.Open();
                SqlCommand myCommand = new SqlCommand(query, myConnection);
                int v1 = (int)myCommand.ExecuteScalar();
                myConnection.Close();

                v1 -= x;
                if (v1 <= 0) {
                    v1 = 0;
                    tempv = 0;

                    query = "update book set available =" + tempv + "where bookname ='" + textBox12.Text + "' AND authorname='" + textBox11.Text + "'";
                    myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                    myConnection = new SqlConnection(myConnectionString);
                    myConnection.Open();
                    myCommand = new SqlCommand(query, myConnection);
                    myCommand.ExecuteNonQuery();
                    myConnection.Close();

                }

                query = "update book set quantity =" + v1 + "where bookname ='" + textBox12.Text + "' AND authorname='" + textBox11.Text + "'";
                myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                myConnection = new SqlConnection(myConnectionString);
                myConnection.Open();
                myCommand = new SqlCommand(query, myConnection);
                myCommand.ExecuteNonQuery();
                myConnection.Close();

                MessageBox.Show("Book Removed");

                textBox12.Text = ""; textBox11.Text = ""; textBox10.Text = "";

            }
            else
            {
                MessageBox.Show("Please Enter Values");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox15.Text != "" && textBox14.Text != "")
            {
                string query = "delete from book where bookname='" + textBox15.Text + "' AND authorname='" + textBox14.Text + "'";
                string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                SqlConnection myConnection = new SqlConnection(myConnectionString);
                myConnection.Open();
                SqlCommand myCommand = new SqlCommand(query, myConnection);
                myCommand.ExecuteNonQuery();
                myConnection.Close();

                MessageBox.Show("Book Deleted");
                textBox15.Text = ""; textBox14.Text = "";
            }
            else {
                MessageBox.Show("Please Enter Values");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox17.Text != "" && textBox16.Text != "" && textBox13.Text != "") {

                int v1 = Int32.Parse(textBox13.Text);
                
                string query = "update book set available =" + 1 + "where bookname ='" + textBox17.Text + "' AND authorname='" + textBox16.Text + "'";
                string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                SqlConnection myConnection = new SqlConnection(myConnectionString);
                myConnection.Open();
                SqlCommand myCommand = new SqlCommand(query, myConnection);
                myCommand.ExecuteNonQuery();
                myConnection.Close();


                query = "select quantity from book where bookname='" + textBox17.Text + "' AND authorname='" + textBox16.Text + "'";
                myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                myConnection = new SqlConnection(myConnectionString);
                myConnection.Open();
                myCommand = new SqlCommand(query, myConnection);
                int v2 = (int)myCommand.ExecuteScalar();
                myConnection.Close();

                v2 += v1;

                query = "update book set quantity =" + v2 + "where bookname ='" + textBox17.Text + "' AND authorname='" + textBox16.Text + "'";
                myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                myConnection = new SqlConnection(myConnectionString);
                myConnection.Open();
                myCommand = new SqlCommand(query, myConnection);
                myCommand.ExecuteNonQuery();
                myConnection.Close();

                MessageBox.Show("Book is Available");
                textBox17.Text = ""; textBox16.Text = ""; textBox13.Text = "";
            }
        }
    }
}
