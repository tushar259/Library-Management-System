﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class AdminChangePassword : Form
    {
        private int userId;
        public AdminChangePassword(int i)
        {
            InitializeComponent();
            userId = i;
        }

        private void AdminChangePassword_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminHome ah = new AdminHome(userId);
            ah.Visible = true;
            this.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Visible = true;
            this.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String query = "select password from login where id =" + userId;
            string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            SqlConnection myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            SqlCommand myCommand = new SqlCommand(query, myConnection);
            string v = (string)myCommand.ExecuteScalar();
            myConnection.Close();

            string x = textBox1.Text;
            string x2 = textBox2.Text;
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                if (x == v&&x!=x2)
                {

                    query = "update login set password = '" + textBox2.Text + "' where id=" + userId;
                    myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
                    myConnection = new SqlConnection(myConnectionString);
                    myConnection.Open();
                    myCommand = new SqlCommand(query, myConnection);
                    myCommand.ExecuteNonQuery();
                    myConnection.Close();
                    MessageBox.Show("Password Changed");
                    textBox1.Text = ""; textBox2.Text = "";

                }
                else if (x == x2)
                {
                    MessageBox.Show("Please enter a new password");
                    textBox1.Text = ""; textBox2.Text = "";
                }
                else
                {
                    MessageBox.Show("The old password you entered is incorrect");
                    textBox1.Text = ""; textBox2.Text = "";
                }
            }
            else {
                MessageBox.Show("Please enter password");
            }
        }
    }
}
