﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class AdminHome : Form
    {
        private int userId;
        public AdminHome(int i)
        {
            InitializeComponent();
            userId = i;
        }

        private void AdminHome_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdminInfo ai = new AdminInfo(userId);
            ai.Visible = true;
            this.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Visible = true;
            this.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminBookInfo abi = new AdminBookInfo(userId);
            abi.Visible = true;
            this.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminUserInfo aui = new AdminUserInfo(userId);
            aui.Visible = true;
            this.Visible = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            AdminAbout aa = new AdminAbout(userId);
            aa.Visible = true;
            this.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AdminUserActivity aua = new AdminUserActivity(userId);
            aua.Visible = true;
            this.Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            AdminChangePassword acp = new AdminChangePassword(userId);
            acp.Visible = true;
            this.Visible = false;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            IncreaseBalance ib = new IncreaseBalance(userId);
            ib.Visible = true;
            this.Visible = false;
        }
    }
}
