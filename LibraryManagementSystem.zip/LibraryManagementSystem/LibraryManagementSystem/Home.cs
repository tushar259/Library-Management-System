﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class Home : Form
    {
        private int userId;
        private string userType,s,s1,s2;
        public Home(int i,string t)
        {
            InitializeComponent();
            userId = i;
            userType = t;

            string query = "select bookname from book";
            string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            SqlConnection myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            SqlCommand myCommand = new SqlCommand(query, myConnection);
            SqlDataReader dr = myCommand.ExecuteReader();
            while (dr.Read())
            {
                s  = dr.GetString(0);
                comboBox1.Items.Add(s);
            }
            myConnection.Close();

            query = "select * from book";
            myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            myCommand = new SqlCommand(query, myConnection);
            dr = myCommand.ExecuteReader();
            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridView1.DataSource = dt;
            }
            myConnection.Close();
            
            
        }

        private void Home_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            s1 = null;
            s1=comboBox1.Text;
            s2 = null;
            s2 = comboBox2.Text;
            if (s1 != ""&&s2!="")
            {

                Borrow b = new Borrow(userId, userType, s1,s2);
                b.Visible = true;
                this.Visible = false;
            }
            else
            {
                MessageBox.Show("select a book and author");
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            comboBox2.Items.Clear();

            string query = "select authorname from book where bookname='"+comboBox1.Text+"'";
            string myConnectionString = ConfigurationManager.ConnectionStrings["LibraryManagementDataBase"].ConnectionString.ToString();
            SqlConnection myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            SqlCommand myCommand = new SqlCommand(query, myConnection);
            SqlDataReader dr = myCommand.ExecuteReader();
            while (dr.Read())
            {
                s2 = dr.GetString(0);
                comboBox2.Items.Add(s2);
            }
            myConnection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Visible = true;
            this.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            UserInfo ui = new UserInfo(userId,userType);
            ui.Visible = true;
            this.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ReturnBook rb = new ReturnBook(userId,userType);
            rb.Visible = true;
            this.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            UserPassword up = new UserPassword(userId, userType);
            up.Visible = true;
            this.Visible = false;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
